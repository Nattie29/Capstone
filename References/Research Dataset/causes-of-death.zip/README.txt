GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Causes of death
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/causes-of-death
	Description: 
	
	
	Date generated: 2022-02-09

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Causes of death"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: -none-
	self: causes-of-death
	children: 
			NULL
		
	
